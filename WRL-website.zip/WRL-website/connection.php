<?php

// Connection details
$host = "localhost";
$username = "smohammadi";
$password = "Password12";
$dbname = "smohammadi_Project";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error){
	die("Connection failed: " . $conn->connect_error);
}
else{
	echo "Successfully connected.";
}
?>
