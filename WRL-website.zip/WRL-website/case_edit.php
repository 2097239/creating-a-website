<?php

include("connection.php");
session_start();

if (!isset($_GET['id']) || !is_numeric($_GET['id']))
{
	header('Location: ./cases.php');
}
else
{
	// Include database connection file
	include('connection.php');

	// Get blog post details

	$id = $_GET['id'];

	$sql = "SELECT * FROM tbl_cases WHERE Case_ID='$id' LIMIT 1";
	$result = mysqli_query($conn, $sql) or die('Unable to run query');
	$row = mysqli_fetch_row($result);


	// Check to see if the form has been submitted
	//if (isset($_POST['submit']))
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		// n12br - inserts line breaks (\n) where new lines occcur in the string
		$firstname = $_POST['firstname'];
		$surname = $_POST['lastname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $haircolour = $_POST['haircolour'];
    $eyecolour = $_POST['eyecolour'];
    $skincolour = $_POST['skincolour'];
    $height = $_POST['height'];
		$note = $_POST['note'];

		if (!empty($firstname) && !empty($surname) && !empty($dob))
		{
			// Create an SQL query to add the comment
			// FINISH OFF THE UPDATE QUERY
			$sql = "UPDATE tbl_cases SET Firstname='$firstname', Surname='$surname', DOB='$dob', Gender='$gender',Haircolour='$haircolour',Eyecolour='$eyecolour',Skincolour='$skincolour',Height='$height' WHERE Case_ID='$id'";
			$sql = "UPDATE tbl_notes SET Note ='$note'";
			// Run the query and store the result in a variable
			$result = mysqli_query($conn, $sql) or die("Could not run query");

			// Close connection to the database
			mysqli_close($conn);

			// Check if query was successful, then post a different message dependant on our result
			if ($result)
			{
				$_SESSION["message"] = '<p style="color: green;">Successfully edited the case.</p>';
			}
			else
			{
				$_SESSION["message"] = '<div class="error"><p>There was an error editing your case, please try again</p></div>';
			}
		}
		else
		{
			$_SESSION["message"] = '<div class="error"><p>Please make sure you fill all fields in before submitting the form.</p></div>';
		}
	}
?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
      <div class="e286_74">
          <div class="e286_89"></div>
          <span class="e286_90">Welcome </span><span class="e286_91">GENERAL</span>
          <div class="e286_123">
              <div class="e286_124"></div>
              <div class="e286_125"></div>
          </div>
          <span class="e286_92"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
          <div class="e286_94"></div>
          <span class="e286_95"><a class="navbutton" href="cases.php">Cases</a></span>
          <span class="e286_120"><a class="navbutton" href="notifications.php">Notifications</a></span>
          <span class="e286_132"><a class="navbutton" href="profile_edit.php?id=<?php echo $_SESSION["id"];?>">Profile</a></span>
          <span class="e286_134"><a class="navbutton" href="search.php">Search</a></span>
          <span class="e422_360">Edit Case</span>
          <div class="e422_402">
          </div>
          <div class="e422_405"></div>
          <div class="e464_174"><span class="e464_175">Track and Trace</span>
            <span class="e464_183"><a class="navbutton" href="home.php">Home</a></span>
            <span class="e464_186"><a class="navbutton" href="contactus.php">Contact us</a></span>
            <span class="e464_187"><a class="navbutton" href="aboutus.php">About us</a></span></div>
          <div class="e468_260"></div>
          <div class="e468_98"></div>
          <div class="e468_106">
              <div class="e286_103"></div>
              <span class="e286_104">Find us here</span><span class="e286_105">Help and Support Call us:<br> +44 800 156 9762</span>
              <span class="e286_106">Contact Us About Us Our Team Privacy Policy </span>
              <div class="e468_99"></div>
              <div class="e468_102"></div>
              <div class="e468_103"></div>
              <div class="e468_104"></div>
          </div>
          <div class="e468_268">
              <div class="e468_269"></div>
              <span class="e468_270"><a class="navbutton" href="logout.php">Logout</a></span>
          </div>
          <div class="e468_292"></div>
          <div class="e468_295"></div>
          <div class="e468_298"></div>
          <div class="e468_301"></div>
          <div class="e468_304"></div>
          <div class="container1">
            <!-- cases Add Form -->

						  <div class="container6">
<form id="addcases" method="post" action="case_edit.php?id=<?php echo $id;?>">
 <label for="fname">First Name</label>
 <input type="text" id="fname" name="firstname" placeholder="Your name.." value="<?php echo $row[1];?>" required>

 <label for="lname">Last Name</label>
 <input type="text" id="lname" name="lastname" placeholder="Your last name.." value="<?php echo $row[2];?>" required>

 <label for="gender" >Gender</label>
 <select id="gender" name="gender">
   <?php if($row[4] == "male"){
     echo '<option selected value="male">Male</option>';
     echo '<option value="female">Female</option>';
   } else{
     echo '<option value="male">Male</option>';
     echo '<option selected value="female">Female</option>';
   }?>
 </select>
 <label for="dob">Date of Birth</label>
 <input type="date" id="dob" name="dob" placeholder="Date of Birth" value="<?php echo $row[3];?>" required>

 <label for="hair">Hair colour</label>
 <input type="text" id="hair" name="haircolour" placeholder="Hair colour.." value="<?php echo $row[5];?>" required>
</div>
<div class="container7">
 <label for="eye">Eye colour</label>
 <input type="text" id="eye" name="eyecolour" placeholder="Eye colour.." value="<?php echo $row[6];?>" required>

 <label for="skin">Skin colour</label>
 <input type="text" id="skin" name="skincolour" placeholder="Skin colour.." value="<?php echo $row[7];?>">

 <label for="height">Height</label>
 <input type="text" id="height" name="height" placeholder="Height .. cm" value="<?php echo $row[8];?>">

 <br>

 <label for="image">Add Image </label>
 <input class="file-upload-input" type="file" onchange="readURL(this)" accept="image/">


 <input type="submit" value="Submit">
</form>

<?php
	if (isset($_SESSION["message"]))
	{
		echo $_SESSION["message"];
		unset($_SESSION["message"]);
	}
?>
</div>
      </div>

  </body>

</html>
<!-- Finishing off our old PHP tags, closing the IF/ELSE statements -->
<?php
	}
?>
