
<?php
// File: .php

// Include database connection file
include_once('connection.php'); // may need to add ./ at the start. I've also added include_once over include

// Connect to the database
$connection;

//session_start();
// If form submitted, insert values into the database.
if($_SERVER["REQUEST_METHOD"] == "POST"){
$firstname = $_POST['Firstname'];
$surname = $_POST['Surname'];
$email = $_POST['Email'];
$password = $_POST['Password'];




// Attach our statement to a variable
$sql = "INSERT INTO tbl_users (Firstname, Surname, Email, Password) VALUES ('$firstname', '$surname', '$email' ,'$password')";



// Connect and run our query
if (mysqli_query($conn, $sql)) {
echo "Registration was successful." , header("location: dashboard.php");
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}



// Close connection
$conn->close();

}else{

?>
<!DOCTYPE html>

<html>
   <head>
      <link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet" />
      <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" />
      <link href="./css/styles.css" rel="stylesheet" />
      <title>Document</title>
      <link href="./css/styles.css" rel="stylesheet" />
      <style>
        /*
          Figma Background for illustrative/preview purposes only.
          You can remove this style tag with no consequence
        */
        body {background: #E5E5E5; }
      </style>
      <title>Document</title>
   </head>
   <body>
      <div class="v239_79">
         <span class="v241_103">Get’s Started.</span><span class="v241_104">Already have an account?</span><span class="v318_138"><a href="login.php" class="navbutton" style="color:blue;"> Login</a></span>
          <!--  <span class="v241_106"><a class="navbutton" href="dashboard.php">Register</a></span> -->
         <div class="v241_102"></div>

         <!-- Navigation bar -->

        <div class="e464_90">
          <span class="e464_91">Track and Trace</span><span class="e464_99"><a  class="navbutton" href="home.php">Home</a></span>
          <span class="e464_100"><a class="active" href="signup.php">Sign up </a></span>
          <span class="e464_101"><a  class="navbutton" href="login.php">Login</a></span>
          <span class="e464_102"><a  class="navbutton" href="contactus.php">Contact us</a></span>
          <span class="e464_103"><a class="navbutton" href="aboutus.php">About us</a> </span>
        </div>

         <div class="v467_93"></div>
         <div class="v468_179">
            <div class="v468_180"></div>
            <span class="v468_181">Find us here</span><span class="v468_182">Help and Support
            Call us:<br>
            +44 800 156 9762</span><span class="v468_183">Contact Us
            About Us
            Our Team
            Privacy Policy
            </span>
            <div class="v468_192"></div>
            <div class="v468_194"></div>
            <div class="v468_195"></div>
            <div class="v468_196"></div>
         </div>
<!-- Login Form -->
         <div class="container4">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" name="register" action="dashboard.php" >

             <label for="fname">First Name</label>
             <input type="text2" id="fname" name="Firstname" placeholder="Name" required>

             <label for="lname">Last Name</label>
             <input type="text2" id="lname" name="Surname" placeholder="Lastname" required>

           <label for="Email">Email address</label>
           <input type="text2" name="Email" placeholder="example@mail.com" required />

           <label for="Password">Password</label>
          <input type="password" name="Password" placeholder="Password" required />
          <form action="dashboard.php" method="POST">
          <input name="register" type="submit" value="Register" />
        </form>

   </form>
     </div>
<?php } ?>
   </body>

</html>
