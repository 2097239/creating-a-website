<?php
// Include
include("connection.php");



// Initialize the session

session_start();

// Check if the user is already logged in, if yes then redirect them to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
header("location: cases.php");
exit;
}
//session_start();
// If form submitted, insert values into the database.



?>
<!DOCTYPE html>
<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>

	<div class="e243_213">
		<span class="e243_227">Login</span><span class="e243_228">Not registered yet? </span>
		</div>


		<div class="e243_269"></div>
		<span class="e244_74">Forgot password?</span><span class="e318_140"><a style="color:blue" class="navbutton" href="signup.php">Sign up</a></span>

    <!-- NAVIGATION BAR -->
		<!--<div class="e464_118">
			<span class="e464_119">Track and Trace</span><span class="e464_127"><a class="navbutton" href="home.php">Home</p></span>
      <span class="e464_128">Sign up </span>
      <span class="e464_129"><a class="active" href="login.php">Login</a></span>
      <span class="e464_130"><a class="navbutton" href="contactus.php">Contact us</a></span>
			<span class="e464_131"><a class="navbutton" href="aboutus.php">About us</a></span>
		</div>-->

    <div class="e464_90">
      <span class="e464_91">Track and Trace</span><span class="e464_99"><a  class="navbutton" href="home.php">Home</a></span>
      <span class="e464_100"><a class="navbutton" href="signup.php">Sign up </a></span>
      <span class="e464_101"><a  class="active" href="login.php">Login</a></span>
      <span class="e464_102"><a  class="navbutton" href="contactus.php">Contact us</a></span>
      <span class="e464_103"><a class="navbutton" href="aboutus.php">About us</a> </span>
    </div>

		<div class="e467_94"></div>
		<div class="e468_161">
			<div class="e468_162"></div>
			<span class="e468_163">Find us here</span><span class="e468_164">Help and Support Call us: <br> +44 800 156 9762</span>
      <span class="e468_165">Contact Us About Us Our Team Privacy Policy </span>
			<div class="e468_174"></div>
			<div class="e468_176"></div>
			<div class="e468_177"></div>
			<div class="e468_178"></div>
    </div>

    <!-- Print a message using GET. This matches to the code above on the IF/ELSE for login. -->
<?php if(isset($_GET["error"])):?>
<div class="error">Invalid Email or Password</div>
<?php endif; ?>

      <div class="container3">
        <form action="login_process.php" method="post" name="login">
        <label for="Email">Email address</label>
        <input type="text2" name="Email" placeholder="example@mail.com" required />
        <label for="Password">Password</label>
    		<input type="password" name="Password" placeholder="Password" required />
    		<input name="submit" type="submit" value="Login" />

</form>
  </div>
		</div>
</body>

          </html>
