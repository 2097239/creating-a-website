<?php

include("connection.php");

session_start();

// If form submitted, insert values into the database.

if($_SERVER["REQUEST_METHOD"] == "POST"){
 $email = $_POST['Email'];
 $password = $_POST['Password'];

 $query = "SELECT * FROM tbl_users WHERE Email='$email' and Password='$password'";

 $result = mysqli_query($conn, $query);
 $rows = mysqli_num_rows($result);

 if($rows > 0){
   $data = mysqli_fetch_assoc($result);
   $_SESSION["id"] = $data ["User_ID"];
   $_SESSION["username"] = $data["Surname"];
   $_SESSION["email"] = $email;
   $_SESSION["loggedin"] = true;
   header("Location: dashboard.php");
 }else{
   echo "<p>Error, unable to check credentials</p>";
 }
}
?>
