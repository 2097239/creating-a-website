<?php

include("connection.php");

session_start();

if(!isset($_SESSION["loggedin"])){
	header("location: logout.php");
}

$sql = "SELECT * FROM tbl_cases";
$result = mysqli_query($conn, $sql);

?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
              </style>
              </head>
              <body>
                 <div class=e265_85>
                    <div  class="e265_99"></div>
                    <span  class="e265_100">Welcome ,<?php echo $_SESSION["username"];?> </span><span  class="e265_101">GENERAL</span>
                    <span  class="e265_102"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
                    <div  class="e265_104"></div>
                    <div  class="e265_139"></div>
                    <span  class="e265_105"><a class="navbutton" href="cases.php">Cases</a></span>
                    <span  class="e265_133"><a class="navbutton" href="notifications.php">Notifications</a></span>
                    <div  class="e265_140"></div>
                    <span  class="e265_143">All cases</span>
                    <div  class="e265_144">
                            <table>
                      <tr>
                        <td>Case_ID</td>
                        <td>Status</td>
                        <td>Name</td>
                        <td>DOB</td>
                        <td>Actions</td>
                      </tr>
                      <?php
                      while($row = mysqli_fetch_assoc($result)){
                        $status = $row["Status_ID"];
                        $status_query = "SELECT * FROM tbl_status WHERE Status_ID='$status' LIMIT 1";
                        $status_result = mysqli_query($conn, $status_query);
                        $status_data = mysqli_fetch_assoc($status_result);

                        ?>
                      <tr>
                        <td><?php echo $row["Case_ID"];?></td>
                        <?php
                        if($status_data["Type"] == "Done"){
                          echo "<td><p style='color: green'>".$status_data['Type']."</p></td>";
                        }
                        elseif($status_data["Type"] == "Pending"){
                          echo "<td><p style='color: orange'>".$status_data['Type']."</p></td>";
                        }
                        else{
                          echo "<td><p style='color: blue'>".$status_data['Type']."</p></td>";
                        }
                        ?>
                        <td><?php echo $row["Firstname"]." ".$row["Surname"];?></td>
                        <td><?php echo $row["DOB"];?></td>
                        <td><a href="viewmore.php?id=<?php echo $row["Case_ID"];?>"> View More </a><br> <a href="case_edit.php?id=<?php echo $row["Case_ID"];?>"> Edit </a>/ <a href="case_delete.php?id=<?php echo $row["Case_ID"];?>"> Delete</a> </td>
                      </tr>
                    <?php } ?>
                    </table></div>
                    <div  class="e265_146"></div>
                    <div  class="e422_84"></div>

                    <div  class="e265_148"></div>

                    <div  class="e266_150"></div>
                    <div  class="e266_152"></div>
                    <div  class="e266_154"></div>
                    <div  class="e422_82"></div>
                    <div class=e268_202>
                       <div class=e268_170>
                          <div  class="e268_171"></div>
                          <span  class="e268_172"><a class="navbutton" href="addcases.php">New case</a></span>
                       </div>
                    </div>
                    <span  class="e268_184"><a class="navbutton" href="profile_edit.php?id=<?php echo $_SESSION["id"];?>">Profile</a></span>
                    <span  class="e268_191"><a class="navbutton" href="search.php">Search</a></span>
                    <div class=e464_146><span  class="e464_147">Track and Trace</span>
                      <span  class="e464_155"><a class="navbutton" href="home.php">Home</a></span>
                      <span  class="e464_158"><a class="navbutton" href="contactus.php">Contact us</a></span>
                      <span  class="e464_159"><a class="navbutton" href="aboutus.php">About us</a></span></div>
                    <div class=e468_264>
                       <div  class="e468_263"></div>
                       <span  class="e464_200"><a class"navbutton" href="logout.php">Logout</a></span>
                    </div>
                    <div  class="e467_96"></div>
                    <div  class="e468_258"></div>
                    <div class=e468_125>
                       <div  class="e468_126"></div>
                       <span  class="e468_127">Find us here</span><span  class="e468_128">Help and Support
                       Call us:<br>
                       +44 800 156 9762</span><span  class="e468_129">Contact Us
                       About Us
                       Our Team
                       Privacy Policy
                       </span>
                       <div  class="e468_138"></div>
                       <div  class="e468_140"></div>
                       <div  class="e468_141"></div>
                       <div  class="e468_142"></div>
                    </div>
                    <div  class="e468_289"></div>
                    <div  class="e468_293"></div>
                    <div  class="e468_296"></div>
                    <div  class="e468_299"></div>
                    <div  class="e468_302"></div>
                    <div  class="e468_306"></div>
                 </div>
              </body>
          </html>
