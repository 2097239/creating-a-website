<?php
// File: blog_manage.php

// Include database connection file
include('connection.php');


?>

<!-- HTML CODE -->
<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
      <div class="e286_74">
          <div class="e286_89"></div>
          <span class="e286_90">Welcome ,<?php echo $_SESSION["username"];?></span><span class="e286_91">GENERAL</span>
          <div class="e286_123">
              <div class="e286_124"></div>
              <div class="e286_125"></div>
          </div>
          <span class="e286_92"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
          <div class="e286_94"></div>
          <span class="e286_95"><a class="navbutton" href="cases.php">Cases</a></span>
          <span class="e286_120"><a class="navbutton" href="#notification">Notifications</a></span>
          <span class="e286_132"><a class="navbutton" href="profile.php">Profile</a></span>
          <span class="e286_134"><a class="navbutton" href="search.php">Search</a></span>
          <span class="e422_360">Add a new case</span>
          <div class="e422_402">
          </div>
          <div class="e422_405"></div>
          <div class="e464_174"><span class="e464_175">Track and Trace</span>
            <span class="e464_183"><a class="navbutton" href="home.php">Home</a></span>
            <span class="e464_186"><a class="navbutton" href="contactus.php">Contact us</a></span>
            <span class="e464_187"><a class="navbutton" href="aboutus.php">About us</a></span></div>
          <div class="e468_260"></div>
          <div class="e468_98"></div>
          <div class="e468_106">
              <div class="e286_103"></div>
              <span class="e286_104">Find us here</span><span class="e286_105">Help and Support Call us:<br> +44 800 156 9762</span>
              <span class="e286_106">Contact Us About Us Our Team Privacy Policy </span>
              <div class="e468_99"></div>
              <div class="e468_102"></div>
              <div class="e468_103"></div>
              <div class="e468_104"></div>
          </div>
          <div class="e468_268">
              <div class="e468_269"></div>
              <span class="e468_270"><a class="navbutton" href="logout.php">Logout</a></span>
          </div>
          <div class="e468_292"></div>
          <div class="e468_295"></div>
          <div class="e468_298"></div>
          <div class="e468_301"></div>
          <div class="e468_304"></div>
<div id="container1">
<?php
$sql = "SELECT * FROM tbl_cases";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0) {
  // MYSQLI_FETCH_ASSOC($RESULT) - fetch a result row, as an associative array (uses a key)
  while($row = mysqli_fetch_assoc($result)) {
    ?><div class="case">
        <p class="firstname"> <?php echo $row["Firstname"]; ?> </p>
        <p class="surname"> <?php echo $row["Surname"]; ?> </p>
        <p class="dob"> <?php echo $row["DOB"]; ?> </p>
        <p class="gender"> <?php echo $row["Gender"]; ?> </p>
        <p class="haircolour"> <?php echo $row["Haircolour"]; ?> </p>
        <p class="eyecolour"> <?php echo $row["Eyecolour"]; ?> </p>
        <p class="skincolour"> <?php echo $row["Skincolour"]; ?> </p>
        <p class="height"> <?php echo $row["Height"]; ?> </p>

        <!-- Edit and Delete Options - we get the relevant ID and post it to the URL. We can then use this with $_GET to display certain information onto our page -->
        <div class="options">
          <span class="option">
            <a href="./case_edit.php?id=<?php echo $row["Case_ID"];?>">Edit</a>
          </span>
          <span class="option">
            <a href="./case_delete.php?id=<?php echo $row["Case_ID"];?>">Delete</a>
          </span>
        </div>
      </div>
    <?php
  }
} else {
  echo "0 results";
}

$conn->close();
?>
</div>


<p class="normal"><a href="./case_add.php">Click Here</a> to add a comment</p>
</div>


</body>
</html>
