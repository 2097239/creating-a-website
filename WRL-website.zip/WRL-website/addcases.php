<?php
// File: guestbook_add.php

// Include database connection file
include('connection.php');

session_start();

if(!isset($_SESSION["loggedin"])){
	header("location: logout.php");
}


?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
      <div class="e286_74">
          <div class="e286_89"></div>
          <span class="e286_90">Welcome ,<?php echo $_SESSION["username"];?></span><span class="e286_91">GENERAL</span>
          <div class="e286_123">
              <div class="e286_124"></div>
              <div class="e286_125"></div>
          </div>
          <span class="e286_92"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
          <div class="e286_94"></div>
          <span class="e286_95"><a class="navbutton" href="cases.php">Cases</a></span>
          <span class="e286_120"><a class="navbutton" href="notifications.php">Notifications</a></span>
          <span class="e286_132"><a class="navbutton" href="profile_edit.php?id=<?php echo $_SESSION["id"];?>">Profile</a></span>
          <span class="e286_134"><a class="navbutton" href="search.php">Search</a></span>
          <span class="e422_360">Case Details</span>
          <div class="e422_402">
          </div>
          <div class="e422_405"></div>
          <div class="e464_174"><span class="e464_175">Track and Trace</span>
            <span class="e464_183"><a class="navbutton" href="home.php">Home</a></span>
            <span class="e464_186"><a class="navbutton" href="contactus.php">Contact us</a></span>
            <span class="e464_187"><a class="navbutton" href="aboutus.php">About us</a></span></div>
          <div class="e468_260"></div>
          <div class="e468_98"></div>
          <div class="e468_106">
              <div class="e286_103"></div>
              <span class="e286_104">Find us here</span><span class="e286_105">Help and Support Call us:<br> +44 800 156 9762</span>
              <span class="e286_106">Contact Us About Us Our Team Privacy Policy </span>
              <div class="e468_99"></div>
              <div class="e468_102"></div>
              <div class="e468_103"></div>
              <div class="e468_104"></div>
          </div>
          <div class="e468_268">
              <div class="e468_269"></div>
              <span class="e468_270"><a class="navbutton" href="logout.php">Logout</a></span>
          </div>
          <div class="e468_292"></div>
          <div class="e468_295"></div>
          <div class="e468_298"></div>
          <div class="e468_301"></div>
          <div class="e468_304"></div>
          <div class="container1">
            <!-- cases Add Form -->
            <?php
            	if (isset($_SESSION["message"]))
            	{
            		echo $_SESSION["message"];
                unset($_SESSION["message"]);
            	}
            ?>
            <div class="container6">
<form id="addcases" method="post" action="add_process.php">
 <label for="fname">First Name</label>
 <input type="text" id="fname" name="firstname" placeholder="Your name.." required>

 <label for="lname">Last Name</label>
 <input type="text" id="lname" name="lastname" placeholder="Your last name.." required>

 <label for="gender" >Gender</label>
 <select id="gender" name="gender">
   <option value="male">Male</option>
   <option value="female">Female</option>
 </select>
 <label for="dob">Date of Birth</label>
 <input type="date" id="dob" name="dob" placeholder="Date of Birth" required>

 <label for="hair">Hair colour</label>
 <input type="text" id="hair" name="haircolour" placeholder="Hair colour.."required>
</div>
<div class="container7">
 <label for="eye">Eye colour</label>
 <input type="text" id="eye" name="eyecolour" placeholder="Eye colour.."required>

 <label for="skin">Skin colour</label>
 <input type="text" id="skin" name="skincolour" placeholder="Skin colour..">

 <label for="height">Height</label>
 <input type="text" id="height" name="height" placeholder="Height .. cm">

 <label for="image">Add Image </label>
 <input class="file-upload-input" type="file" onchange="readURL(this)" accept="image/">
<br/>

 <input type="submit" value="Submit">
</form>
</div>
      </div>

  </body>

          </html>
