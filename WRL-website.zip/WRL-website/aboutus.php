
<?php
// File: .php

// Include database connection file
include_once('connection.php'); // may need to add ./ at the start. I've also added include_once over include

session_start();
// Connect to the database
$connection;

?>


<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
          	<div class="e211_209">
          		<div class="e211_232"></div>
          		<span class="e216_128">About us</span>
          		<span class="e216_129">
          			Mi, tellus ut tristique fusce at eleifend. Iaculis molestie purus lectus pellentesque proin purus. Venenatis tortor quis vitae facilisi. Id nec vitae porta porta aliquet viverra elementum. Accumsan quis porttitor enim, aenean
          			quis a. Commodo gravida nulla nunc rhoncus, faucibus non, ornare aliquam. Scelerisque senectus enim dignissim volutpat, sed amet. Tellus erat malesuada rutrum semper in leo, lacinia. Nunc libero dignissim morbi fermentum nulla.
          		</span>
          		<div class="e464_90">
          			<span class="e464_91">Track and Trace</span>
                <span class="e464_99"><a  class="navbutton" href="home.php">Home</a></span>
                <?php if(isset($_SESSION["loggedin"])){
                  echo ' <div class="e208_81"><span class="e464_206"><a class="navbutton" href="dashboard.php">Dashboard</a></span></div>
                  <div class="e208_82"><a class="navbutton" href="logout.php"> Logout</a></div>';
                } else {
                   ?>               <span  class="e208_81"><a class="navbutton" href="signup.php"> Sign up </a> </span>
                                 <span  class="e208_82"><a class="navbutton" href="login.php"> Login</a></span>
                 <?php } ?>
                <span class="e464_102"><a  class="navbutton" href="contactus.php">Contact us</a></span>
                <span class="e464_103"><a class="active" href="#aboutus">About us</a> </span>
          		</div>
          		<div class="e467_92"></div>
          		<div class="e468_197">
          			<div class="e468_198"></div>
          			<span class="e468_199">Find us here</span><span class="e468_200">Help and Support Call us: +44 800 156 9762</span><span class="e468_201">Contact Us About Us Our Team Privacy Policy </span>
          			<div class="e468_210"></div>
          			<div class="e468_212"></div>
          			<div class="e468_213"></div>
          			<div class="e468_214"></div>
          		</div>
          	</div>
          </body>
          </html>
