
<?php
// File: .php

// Include database connection file
include_once('connection.php'); // may need to add ./ at the start. I've also added include_once over include

session_start();
// Connect to the database
$connection;

?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
    	<div class="e211_193">
    		<span class="e213_233">Get in touch </span>
    		<div class="e213_238"></div>
    		<div class="e213_239"></div>
    		<div class="e214_248"></div>
    		<span class="e214_249">We are here for help! How can we help?</span>
    		<div class="e214_329"></div>

    	<!--	<div class="e464_76">
    			<span class="e464_77">Track and Trace</span><span class="e464_85"><a href="home.php"> Home</a></span>
          <span class="e464_86"<a class="navbutton" href="signup.php">Sign up</a></span>
          <span class="e464_87"><a  class="navbutton" href="login.php">Login</a></span>
          <span class="e464_88"> <a class="active" href="#contactus" >Contact us</a> </span>
          <span class="e464_89"><a href="aboutus.php">About us<a/></span>
    		</div> -->

        <div class="e464_90">
          <span class="e464_91">Track and Trace</span><span class="e464_99"><a  class="navbutton" href="home.php">Home</a></span>
          <?php if(isset($_SESSION["loggedin"])){
            echo ' <div class="e208_81"><span class="e464_206"><a class="navbutton" href="dashboard.php">Dashboard</a></span></div>
            <div class="e208_82"><a class="navbutton" href="logout.php"> Logout</a></div>';
          } else {
             ?>               <span  class="e208_81"><a class="navbutton" href="signup.php"> Sign up </a> </span>
                           <span  class="e208_82"><a class="navbutton" href="login.php"> Login</a></span>
           <?php } ?>
          <span class="e464_102"><a  class="active" href="contactus.php">Contact us</a></span>
          <span class="e464_103"><a class="navbutton" href="aboutus.php">About us</a> </span>
        </div>

    		<div class="e467_90"></div>
    		<div class="e468_215">
    			<div class="e468_216"></div>
    			<span class="e468_217">Find us here</span><span class="e468_218">Help and Support Call us:<br> +44 800 156 9762</span><span class="e468_219">Contact Us About Us Our Team Privacy Policy </span>
    			<div class="e468_228"></div>
    			<div class="e468_230"></div>
    			<div class="e468_231"></div>
    			<div class="e468_232"></div>
    		</div>
        <div class="container2">
        <form action="/action_page.php">
      <label for="fname">Full Name</label>
      <input type="text2" id="fname" name="fullname" placeholder="Your Full name..">

      <label for="phone">Enter your phone number:</label>

      <input type="tel" id="phone" name="phone" placeholder="Format: 123-456-7890"
             pattern="[0-9]{3}-[0-9]{4}-[0-9]{3}"
             required>
<br>
<br>
      <label for="email">Enter your email address: </label>

      <input type="email" id="email" placeholder="Format: example@mail.com"
             pattern=".+@mail\.com" size="30" required>
<br>

<br>
             <label for="message"> Message </label>
             <textarea cols="45" rows="10" type="text3"  id="message"
             name="message"
             placeholder="Enter your message here"></textarea>

      <input type="submit" value="Submit">
      </form>
      </div>

    	</div>
          </body>
          </html>
