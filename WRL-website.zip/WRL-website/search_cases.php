<?php

// Include database connection file
include_once('connection.php');

// Check Submission
if (isset($_POST['submit'])){
  header("Location: searchresults.php?searchterm=".$_POST["searchterm"]);
}

?>
