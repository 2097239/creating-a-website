<?php

include("connection.php");
session_start();

if(!isset($_SESSION["loggedin"])){
	header("location: logout.php");
}

$sql = "SELECT * FROM tbl_users";
$result = mysqli_query($conn, $sql);

?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
             <div class=e282_120>
                <div  class="e282_135"></div>
                <span  class="e282_136">Welcome ,<?php echo $_SESSION["username"];?></span><span  class="e282_137">GENERAL</span>
                <span  class="e282_138"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
                <div  class="e282_140"></div>
                <span  class="e282_142"><a class="navbutton" href="cases.php">Cases</a></span>
                <span  class="e282_167"><a class="navbutton" href="notifications.php">Notifications</a></span>
                <div class=e282_204>
                   <div  class="e282_141"></div>
                   <div  class="e282_170"></div>
                </div>
                <span  class="e282_171">Profile</span>
                <span  class="e282_198"><a class="navbutton" href="#profile">Profile</a></span>
                <span  class="e282_200"><a class="navbutton" href="search.php">Search</a></span>
                <div class=e464_160><span  class="e464_161">Track and Trace</span>
                  <span  class="e464_169"><a class="navbutton" href="home.php">Home</a></span>
                  <span  class="e464_172"><a class="navbutton" href="contactus.php">Contact us</a></span>
                  <span  class="e464_173"><a class="navbutton" href="aboutus.php">About us</a></span></div>
                <div  class="e468_259"></div>
                <div  class="e467_97"></div>
                <div class=e468_107>
                   <div  class="e468_108"></div>
                   <span  class="e468_109">Find us here</span><span  class="e468_110">Help and Support
                   Call us:<br>
                   +44 800 156 9762</span>
                   <span  class="e468_111">Contact Us
                   About Us
                   Our Team
                   Privacy Policy
                   </span>
                   <div  class="e468_120"></div>
                   <div  class="e468_122"></div>
                   <div  class="e468_123"></div>
                   <div  class="e468_124"></div>
                </div>
                <div class=e468_265>
                   <div  class="e468_266"></div>
                   <span  class="e468_267"><a class="navbutton" href="logout.php">Logout</a></span>
                </div>
                <div  class="e468_290"></div>
                <div  class="e468_294"></div>
                <div  class="e468_297"></div>
                <div  class="e468_300"></div>
                <div  class="e468_303"></div>
             </div>
             <div class="container5">
             <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text2" id="fname" name="firstname" placeholder="First name" required>

    <label for="lname">Last Name</label>
    <input type="text2" id="lname" name="lastname" placeholder="Last name">

    <label for="email">Email address: </label>

    <input type="email" id="email" placeholder="Format: example@mail.com"
           pattern=".+@mail\.com" size="30" required>

           <label for="phone">Phone number:</label>

           <input type="tel" id="phone" name="phone" placeholder="Format: 123-456-7890"
                  pattern="[0-9]{3}-[0-9]{4}-[0-9]{3}"
                  required>

    <label for="dob">Date of Birth</label>
    <input type="date" id="dob" name="dob" placeholder="Date of Birth">

    <label for="Password">Current Password</label>
   <input type="password" name="Password" placeholder="Current Password" required />

   <label for="Password">New Password</label>
  <input type="password" name="Password" placeholder="New Password" required />

    <input type="submit" value="Save">
   </form>
         </div>

          </body>
          </html>
