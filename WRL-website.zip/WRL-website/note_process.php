<?php

include("connection.php");
session_start();

$case_id = $_GET["id"];
$note = $_POST["note"];
$user_id = $_SESSION["id"];
$date = date("Y-m-d");

$sql = "INSERT INTO tbl_notes (Case_ID, Note, User_ID, Date) VALUES ('$case_id', '$note', '$user_id', '$date')";
$result = mysqli_query($conn, $sql);

header("location: viewmore.php?id=".$case_id);

?>
