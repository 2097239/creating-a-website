<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
            <div class=e243_213><span  class="e243_227">Login</span><span  class="e243_228">Not registered yet? </span><div class=e243_229><div  class="e243_230"></div><span  class="e243_231">Login</span></div><span  class="e243_253">Email address</span><span  class="e243_254">Password</span><div  class="e243_261"></div><span  class="e243_262">Remember me</span><div  class="e243_269"></div><span  class="e244_74">Forgot password?</span><span  class="e318_140">Sign up</span><div class=e464_118><span  class="e464_119">Track and Trace</span><span  class="e464_127">Home</span><span  class="e464_128">Sign up </span><span  class="e464_129">Login</span><span  class="e464_130">Contact us</span><span  class="e464_131">About us</span></div><div  class="e467_94"></div><div class=e468_161><div  class="e468_162"></div><span  class="e468_163">Find us here</span><span  class="e468_164">Help and Support

Call us:
+44 800 156 9762</span><span  class="e468_165">Contact Us
About Us
Our Team
Privacy Policy
</span><div  class="e468_174"></div><div  class="e468_176"></div><div  class="e468_177"></div><div  class="e468_178"></div></div><div  class="e468_313"></div><div  class="e468_314"></div><div  class="e468_315"></div><span  class="e468_316">***********</span><div  class="e468_317"></div><span  class="e468_318">Example@mail.com</span><div  class="e468_319"></div></div>
          </body>
          </html>
