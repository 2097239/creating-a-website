
<?php
// File: .php

// Include database connection file
include('connection.php');
session_start();

if(!isset($_SESSION["loggedin"])){
	header("location: logout.php");
}
?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>
          <body>
            <div class="e250_83">
    <div class="e272_235">
          <table>
    <tr>
      <td>Total Cases</td>
      <td>Complete Cases</td>
      <td>Pending Cases</td>
    </tr>
    <tr>
    <?php
      $sql = "SELECT * FROM tbl_cases ";
      $result = mysqli_query($conn,$sql);
      $count = mysqli_num_rows($result);
      $pending = 0;
      $complete = 0;

      while($row = mysqli_fetch_assoc($result)){
        if($row["Status_ID"] == 2 || $row["Status_ID"] == 3){
          $pending++;
        }
        else{
          $complete++;
        }
      }
      ?>
      <td><?php echo $count; ?></td>
      <td><?php echo $complete;?> </td>
      <td><?php echo $pending;?> </td>
    </tr>
  </table></div>
        <div class="e253_98"></div>
        <span class="e253_99">Welcome ,<?php echo $_SESSION["username"];?> </span><span class="e253_100">GENERAL</span>
        <div class="e253_104"></div>
        <span class="e253_105"><a class="navbutton" href="cases.php">Cases</a></span>
<!--
        <span class="e256_143">Total Cases</span>
        <span class="e256_144">Complete cases</span>
        <span class="e256_145">Pending cases</span> -->
        <span class="e265_81"><a class="navbutton" href="notifications.php">Notifications</a></span>
        <div class="e268_175"></div>
        <div class="e268_176"></div>
        <span class="e253_101"><a class="navbutton" href="#dasdhboard">Dashboard</a></span>
        <div class="e268_194"></div>
        <span class="e268_197"><a class="navbutton" href="search.php">Search</a></span>
        <div class="e268_203">
            <div class="e268_204">
                <div class="e268_205"></div>
                <span class="e268_206"><a class="navbutton" href="addcases.php">New case</a></span>
            </div>
            <div class="e468_305"></div>
        </div>
        <div class="e272_228">
            <div class="e272_229">
                <div class="e272_230"></div>
                <span class="e272_231"><a class="navbutton" href="cases.php"> All cases</a></span>
            </div>
        </div>
        <span class="e272_214"><a class="navbutton"  href="profile_edit.php?id=<?php echo $_SESSION["id"];?>"> Profile</a></span>
        <div class="e272_236"></div>
        <div class="e272_237"></div>
        <div class="e272_239"></div>
        <!--
        <span class="e272_240">0</span>
        <span class="e272_241">1</span>
        <span class="e272_242">0</span>
      -->
        <span class="e272_263">Dashboard</span>
        <div class="e464_132"><span class="e464_133">Track and Trace</span>
          <span class="e464_141"><a class="navbutton" href="home.php">Home</a></span>
          <span class="e464_144"><a class="navbutton" href="contactus.php">Contact us</a></span>
          <span class="e464_145"><a class="navbutton" href="aboutus.php">About us</a></span></div>
        <div class="e464_201"><span class="e464_206"><a class="navbutton" href="logout.php">Logout</a></span></div>
        <div class="e467_95"></div>
        <div class="e468_143">
            <div class="e468_144"></div>
            <span class="e468_145">Find us here</span><span class="e468_146">Help and Support Call us: <br> +44 800 156 9762</span><span class="e468_147">Contact Us About Us Our Team Privacy Policy </span>
            <div class="e468_156"></div>
            <div class="e468_158"></div>
            <div class="e468_159"></div>
            <div class="e468_160"></div>
        </div>
        <div class="e486_5"></div>
        <div class="e468_279"></div>
        <div class="e468_278"></div>
        <div class="e468_277"></div>
        <div class="e468_285"></div>
        <div class="e468_275"></div>
    </div>
</body>
          </html>
