<?php
// File: blog_delete.php

// Check if the ID has been set in the URL, so that we can only show the post that we want to
if (!isset($_GET['id']) || !is_numeric($_GET['id']))
{
 // Send the user back to management if ID isn't set
 // Remember, ! means NOT and || means OR in PHP
 header('Location: ./cases.php');
}
else
{
 // Include our connection file
 include('connection.php');

 // Get the ID so we can show specific information on the page
 $id = $_GET['id'];

 // Run our query and attach them to our row
 $sql = "SELECT * FROM tbl_cases WHERE Case_ID='$id' LIMIT 1";
 $result = mysqli_query($conn, $sql);
?>

<!-- HTML STARTS HERE -->
<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>      <div class="e286_74">
                    <div class="e286_89"></div>
                    <span class="e286_90">Welcome </span><span class="e286_91">GENERAL</span>
                    <div class="e286_123">
                        <div class="e286_124"></div>
                        <div class="e286_125"></div>
                    </div>
                    <span class="e286_92"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
                    <div class="e286_94"></div>
                    <span class="e286_95"><a class="navbutton" href="cases.php">Cases</a></span>
                    <span class="e286_120"><a class="navbutton" href="notifications.php">Notifications</a></span>
                    <span class="e286_132"><a class="navbutton" href="profile.php">Profile</a></span>
                    <span class="e286_134"><a class="navbutton" href="search.php">Search</a></span>
                    <span class="e422_360">Delete Case</span>
                    <div class="e422_402">
                    </div>
                    <div class="e422_405"></div>
                    <div class="e464_174"><span class="e464_175">Track and Trace</span>
                      <span class="e464_183"><a class="navbutton" href="home.php">Home</a></span>
                      <span class="e464_186"><a class="navbutton" href="contactus.php">Contact us</a></span>
                      <span class="e464_187"><a class="navbutton" href="aboutus.php">About us</a></span></div>
                    <div class="e468_260"></div>
                    <div class="e468_98"></div>
                    <div class="e468_106">
                        <div class="e286_103"></div>
                        <span class="e286_104">Find us here</span><span class="e286_105">Help and Support Call us:<br> +44 800 156 9762</span>
                        <span class="e286_106">Contact Us About Us Our Team Privacy Policy </span>
                        <div class="e468_99"></div>
                        <div class="e468_102"></div>
                        <div class="e468_103"></div>
                        <div class="e468_104"></div>
                    </div>
                    <div class="e468_268">
                        <div class="e468_269"></div>
                        <span class="e468_270"><a class="navbutton" href="logout.php">Logout</a></span>
                    </div>
                    <div class="e468_292"></div>
                    <div class="e468_295"></div>
                    <div class="e468_298"></div>
                    <div class="e468_301"></div>
                    <div class="e468_304"></div>
<!-- Check we have a returned result from the DB, and that A hasn't been set. We are going to be using 'a' to post a success/error message later -->
 <div id="container1">
 <?php
   if ($result && !isset($_GET['a']))
   {
       ?>

       <!-- Display the post, so the user knows which article they're about to delete -->
       <div  class="e265_144">

 <!-- Check the echo of $id - we use this to set 'a' to confirm, which should allow us to successfully run the delete script -->
   <div class="options">
     <br><span class="option"><a style="color:red ;"  href="case_delete.php?id=<?php echo $id; ?>&a=confirm">Confirm Deletion</a></span><br><br>
     <span class="option"><a style="color:blue ;" href="cases.php">Go back to manage cases</a></span>
   </div>
 <?php
   }
   // Remember where they pressed the confirm button? This is where we check the value of 'a'
   elseif ($result && $_GET['a'] == "confirm")
   {
     $sql = "DELETE FROM tbl_cases WHERE Case_ID='$id' LIMIT 1";
     $result = mysqli_query($conn, $sql);

     if ($result)
     {
 ?>
   <!-- If our query was successful, we print out our success message -->
    <div  class="e265_144">
   <div class="success">
     <p>This blog post has been successfully deleted.  <a href="./case_manage.php">Click Here</a> to return to the Blog Management page</p>
   </div>
 </div>

 <?php
     }
     else
     {
 ?>

 <!-- If our query wasn't successful, we print out that there was an error -->
    <div  class="e265_144">
   <div class="error">
     <p>There has been an error processing your request.  <a href="./case_manage.php">Click Here</a> to return to the Blog Management page</p>
   </div>
 </div>

 <?php
     }
   }
   else
   {
 ?>

 <!-- If we couldn't get the 'a' value, we print out that there was an error -->
     <div  class="e265_144">
  <div class="error">
     <p>There has been an error processing your request.  <a href="./case_manage.php">Click Here</a> to return to the Blog Management page</p>
   </div>
 </div>

 <?php
   }
 ?>

 </div>

 <?php
 $conn->close();
 ?>

 </div>

 <?php

}

 ?>
