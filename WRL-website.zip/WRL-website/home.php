
<?php
// File: .php

// Include database connection file
include_once('connection.php'); // may need to add ./ at the start. I've also added include_once over include

session_start();

// Connect to the database
$connection;

?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
            <div class=e208_71><div  class="e250_81"></div><div class=e274_90><span  class="e208_72">Track and Trace</span>
              <span  class="e208_80"><a class="active" href="#home">Home</a></span>
             <?php if(isset($_SESSION["loggedin"])){
               echo ' <div class="e208_81"><span class="e464_206"><a class="navbutton" href="dashboard.php">Dashboard</a></span></div>
               <div class="e208_82"><a class="navbutton" href="logout.php"> Logout</a></div>';
             } else {
                ?>               <span  class="e208_81"><a class="navbutton" href="signup.php"> Sign up </a> </span>
                              <span  class="e208_82"><a class="navbutton" href="login.php"> Login</a></span>
              <?php } ?>

              <span  class="e208_83"><a class="navbutton" href="contactus.php"> Contact us </a> </span>
               <span  class="e208_84"> <a class="navbutton" href="aboutus.php">About us</a></span></div>
               <span  class="e208_85">Get help find missing people</span>
                <div class=e250_80><div  class="e208_87"></div>
                <span  class="e208_88"><a href="login.php">Get started</a></span></div>
                <span  class="e208_105">Steps to get started </span>
                <span  class="e208_106">Fill out the form </span>
                <span  class="e208_107">Administration progress</span><span  class="e208_108">Find the missing person</span><div  class="e208_109"></div>
                <span  class="e208_110">How we work</span><div  class="e208_111"></div><span  class="e208_131">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Pellentesque vestibulum id id turpis leo sed auctor at.
  Et, bibendum mi lobortis felis lectus. Tortor sed egestas tortor pulvinar odio fames eu. Suspendisse tincidunt non turpis risus enim.</span><span  class="e273_286">Accumsan integer penatibus ultrices mattis mi orci quis. Sit odio orci non at.</span><div  class="e208_86"></div><div  class="e467_91"></div><div class=e468_233><div  class="e468_234"></div><span  class="e468_235">Find us here</span><span  class="e468_236">Help and Support

  Call us:<br>
  +44 800 156 9762</span><span  class="e468_237">Contact Us
  About Us
  Our Team
  Privacy Policy
  </span><div  class="e468_246"></div><div  class="e468_248"></div><div  class="e468_249"></div><div  class="e468_250"></div></div><div  class="e468_252"></div><div  class="e468_251"></div><div  class="e468_253"></div></div>
          </body>
          </html>
