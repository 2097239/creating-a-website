
<?php
// File: .php

// Include database connection file
include_once('connection.php'); // may need to add ./ at the start. I've also added include_once over include
session_start();

if(!isset($_SESSION["loggedin"])){
	header("location: logout.php");
}
// Connect to the database
$sql = "SELECT * FROM tbl_cases";
$result = mysqli_query($conn, $sql);

$connection;

?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>
          <body>
            <div class="e250_83">
    <div class="e272_235">
<p style="color:red; text-align:center;"><font size="+8">There is no notification</font> </p><br>
<p style="text-align: center;"><font size="+2">Return to <a href="cases.php" style="color:blue;">All Cases </font></a></p>
          </div>
        <div class="e253_98"></div>
        <span class="e253_99">Welcome ,<?php echo $_SESSION["username"];?></span><span class="e253_100">GENERAL</span>
        <div class="e253_104"></div>
        <span class="e253_105"><a class="navbutton" href="cases.php">Cases</a></span>
<!--
        <span class="e256_143">Total Cases</span>
        <span class="e256_144">Complete cases</span>
        <span class="e256_145">Pending cases</span> -->
        <div class="e268_178"></div>
        <span class="e265_81"><a class="navbutton" href="#notification">Notifications</a></span>
        <div class="e268_176"></div>
        <span class="e253_101"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
        <div class="e268_194"></div>
        <span class="e268_197"><a class="navbutton" href="search.php">Search</a></span>
        <div class="e268_203">
            <div class="e268_204">

            </div>
        </div>
        <span class="e272_214"><a class="navbutton"href="profile_edit.php?id=<?php echo $_SESSION["id"];?>"> Profile</a></span>
        <div class="e272_236"></div>
        <div class="e272_237"></div>
        <div class="e272_239"></div>
        <!--
        <span class="e272_240">0</span>
        <span class="e272_241">1</span>
        <span class="e272_242">0</span>
      -->

        <div class="e464_132"><span class="e464_133">Track and Trace</span>
          <span class="e464_141"><a class="navbutton" href="home.php">Home</a></span>
          <span class="e464_144"><a class="navbutton" href="contactus.php">Contact us</a></span>
          <span class="e464_145"><a class="navbutton" href="aboutus.php">About us</a></span></div>
        <div class="e464_201"><span class="e464_206"><a class="navbutton" href="logout.php">Logout</a></span></div>
        <div class="e467_95"></div>
        <div class="e468_143">
            <div class="e468_144"></div>
            <span class="e468_145">Find us here</span><span class="e468_146">Help and Support Call us: <br> +44 800 156 9762</span><span class="e468_147">Contact Us About Us Our Team Privacy Policy </span>
            <div class="e468_156"></div>
            <div class="e468_158"></div>
            <div class="e468_159"></div>
            <div class="e468_160"></div>
        </div>
        <div class="e486_5"></div>
        <div class="e468_279"></div>
        <div class="e468_278"></div>
        <div class="e468_277"></div>
        <div class="e468_285"></div>
        <div class="e468_275"></div>
    </div>
</body>
          </html>
