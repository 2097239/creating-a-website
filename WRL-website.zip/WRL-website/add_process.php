<?php
include("connection.php");

session_start();

	// Check to see all fields have been completed
	$firstname = $_POST['firstname'];
	$surname = $_POST['lastname'];
  $dob = $_POST["dob"];
  $gender = $_POST['gender'];
  $haircolour = $_POST['haircolour'];
  $eyecolour = $_POST['eyecolour'];
  $skincolour = $_POST['skincolour'];
  $height = $_POST['height'];
	$user_id = $_SESSION["id"];


	if (!empty($firstname) && !empty($surname) && !empty($dob) && !empty($gender) && !empty($haircolour) && !empty($eyecolour) && !empty($skincolour) && !empty($height))
	{

		// Create an SQL query to add the comment
		$sql = "INSERT INTO tbl_cases (Firstname, Surname, DOB, Gender, Haircolour, Eyecolour, Skincolour, Height, User_ID) VALUES ('$firstname', '$surname', '$dob', '$gender', '$haircolour', '$eyecolour', '$skincolour', '$height', '$user_id')";

		// Run the query and store the result in a variable
		$result = mysqli_query($conn, $sql) or die("Could not run query");

		// Close connection to the database
		mysqli_close($conn);

		// Check if query was successful
		if ($result)
		{
			$_SESSION["message"] = "<p style='color: green'>Successfully added the case.</p>";
		}
		else
		{
			$_SESSION["message"] = '<div class="error"><p>There was an error adding your case, please try again</p></div>';
		}
	}
	else
	{
		$_SESSION["message"] = '<div class="error"><p>Please make sure you fill all fields in before submitting the form.</p></div>';
	}

  header("location: addcases.php");

?>
