<?php

include("connection.php");
session_start();

if (!isset($_GET['id']))
{
	header('Location: ./profile.php');
}
else
{
	// Include database connection file
	include('connection.php');

	// Get blog post details

	$id = $_GET['id'];

	$sql = "SELECT * FROM tbl_users WHERE User_ID='$id' LIMIT 1";
	$result = mysqli_query($conn, $sql) or die('Unable to run query');
	$row = mysqli_fetch_row($result);


	// Check to see if the form has been submitted
	//if (isset($_POST['submit']))
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		// n12br - inserts line breaks (\n) where new lines occcur in the string
		$firstname = $_POST['firstname'];
		$surname = $_POST['lastname'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $role_id = $_POST['role_id'];

		if (!empty($firstname) && !empty($surname) && !empty($dob))
		{
			// Create an SQL query to add the comment
			// FINISH OFF THE UPDATE QUERY
			$sql = "UPDATE tbl_users SET Firstname='$firstname', Surname='$surname', DOB='$dob', Email='$email', Role_ID='$role_id' WHERE User_ID='$id'";
			// Run the query and store the result in a variable
			$result = mysqli_query($conn, $sql) or die("Could not run query");

			// Close connection to the database
			mysqli_close($conn);

			// Check if query was successful, then post a different message dependant on our result
			if ($result)
			{
				$_SESSION["message"] = '<p style="color: green;">Successfully edited the case.</p>';
			}
			else
			{
				$_SESSION["message"] = '<div class="error"><p>There was an error editing your case, please try again</p></div>';
			}
		}
		else
		{
			$_SESSION["message"] = '<div class="error"><p>Please make sure you fill all fields in before submitting the form.</p></div>';
		}
	}
?>

<html lang="en">
          <head>
            <meta charset="utf-8">

            <title>Html Generated</title>
            <meta name="description" content="Figma htmlGenerator">
            <meta name="author" content="htmlGenerator">
            <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Puritan&display=swap" rel="stylesheet">

            <link rel="stylesheet" href="css/styles.css">

            <style>
              /*
                Figma Background for illustrative/preview purposes only.
                You can remove this style tag with no consequence
              */
              body {background: #E5E5E5; }
            </style>

          </head>

          <body>
             <div class=e282_120>
                <div  class="e282_135"></div>
                <span  class="e282_136">Welcome ,<?php echo $_SESSION["username"];?></span><span  class="e282_137">GENERAL</span>
                <span  class="e282_138"><a class="navbutton" href="dashboard.php">Dashboard</a></span>
                <div  class="e282_140"></div>
                <span  class="e282_142"><a class="navbutton" href="cases.php">Cases</a></span>
                <span  class="e282_167"><a class="navbutton" href="notifications.php">Notifications</a></span>
                <div class=e282_204>
                   <div  class="e282_141"></div>
                   <div  class="e282_170"></div>
                </div>
                <span  class="e282_171">Profile</span>
                <span  class="e282_198"><a class="navbutton" href="profile.php">Profile</a></span>
                <span  class="e282_200"><a class="navbutton" href="search.php">Search</a></span>
                <div class=e464_160><span  class="e464_161">Track and Trace</span>
                  <span  class="e464_169"><a class="navbutton" href="home.php">Home</a></span>
                  <span  class="e464_172"><a class="navbutton" href="contactus.php">Contact us</a></span>
                  <span  class="e464_173"><a class="navbutton" href="aboutus.php">About us</a></span></div>
                <div  class="e468_259"></div>
                <div  class="e467_97"></div>
                <div class=e468_107>
                   <div  class="e468_108"></div>
                   <span  class="e468_109">Find us here</span><span  class="e468_110">Help and Support
                   Call us:<br>
                   +44 800 156 9762</span>
                   <span  class="e468_111">Contact Us
                   About Us
                   Our Team
                   Privacy Policy
                   </span>
                   <div  class="e468_120"></div>
                   <div  class="e468_122"></div>
                   <div  class="e468_123"></div>
                   <div  class="e468_124"></div>
                </div>
                <div class=e468_265>
                   <div  class="e468_266"></div>
                   <span  class="e468_267"><a class="navbutton" href="logout.php">Logout</a></span>
                </div>
                <div  class="e468_290"></div>
                <div  class="e468_294"></div>
                <div  class="e468_297"></div>
                <div  class="e468_300"></div>
                <div  class="e468_303"></div>
             </div>
             <div class="container5">
             <form id="addcases" method="post" action="profile_edit.php=<?php echo $id;?>">
    <label for="fname">First Name</label>
    <input type="text2" id="fname" name="firstname" placeholder="First name" value="<?php echo $row[1];?>">

    <label for="lname">Last Name</label>
    <input type="text2" id="lname" name="lastname" placeholder="Last name"  value="<?php echo $row[2];?>">

    <label for="email">Email address: </label>

    <input type="email" id="email" placeholder="Format: example@mail.com" name="email"  value="<?php echo $row[4];?>"
           pattern=".+@mail\.com" size="30" >

    <label for="dob">Date of Birth</label>
    <input type="date" id="dob" name="dob" placeholder="Date of Birth"  value="<?php echo $row[3];?>">

    <label for="Password">Current Password</label>
   <input type="password" name="password" placeholder="Current Password" />

   <label for="Password">New Password</label>
  <input type="password" name="Password" placeholder="New Password"  />

    <input type="submit" value="Submit">
   </form>

<?php
  	if (isset($_SESSION["message"]))
   	{
   		echo $_SESSION["message"];
   		unset($_SESSION["message"]);
   	}
?>
   </div>
         </div>

     </body>

   </html>
   <!-- Finishing off our old PHP tags, closing the IF/ELSE statements -->
<?php
   	}
?>
